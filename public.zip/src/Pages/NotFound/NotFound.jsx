import React from 'react';

const NotFound = () => {
    return (
        <div className='text-center mb-3'>
            <img src="https://cdn.mos.cms.futurecdn.net/PuXipAW3AXUzUJ4uYyxPKC-1200-80.jpg" alt="" />
        </div>
    );
};

export default NotFound;