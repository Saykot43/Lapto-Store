import React from 'react';
import './ProductDetail.css'

const ProductDetail = () => {
    
    return (
        <div className='container'>
            <p>product details</p>
        </div>
    );
};

export default ProductDetail;